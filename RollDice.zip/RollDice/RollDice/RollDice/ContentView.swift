import SwiftUI

struct ContentView: View {
    @State var value:Int = 1
    var colours:[Color] = [.red,.green,.orange,.yellow,.blue,.pink]
    func rolldice(){
        value=Int.random(in: 1...6)
    }
    var body: some View {
        ZStack{
            colours[value-1]
            grid(value: value)
        }
        .ignoresSafeArea()
        .onTapGesture{
            rolldice()
        }
        }
        
    }

#Preview {
    ContentView()
}

